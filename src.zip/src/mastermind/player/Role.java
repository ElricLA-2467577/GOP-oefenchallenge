// @author Mathijs - group 13

package mastermind.player;

public enum Role {
    BREAKER,
    MAKER;
}
