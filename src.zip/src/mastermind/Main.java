package mastermind;

// @author Mathijs - group 13

public class Main {
    public static void main(String[] args) {

        MasterMindGame game = new MasterMindGame();
        game.start();

    }
}
