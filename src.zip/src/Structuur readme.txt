MasterMindGame: hoofdklasse, bevat gameloop logica en initialiseerd hoofddelen, beavt info over de staat van het spel (zoals het aantal resterende gokken)
GameView: view klasse, doet alle I/O
Player: abstracte klasse met rol (maker/breaker), afgeleid naar -> HumanPlayer en ComputerPlayer om strategie en input behaviour te kunnen implementeren
Strategy: interface voor botstrategie, wordt geimplementeerd door -> RandomStrategy om strategie gedrag aan te passen aan de gekozen strategie
Board: verwerkt alle row input (gok) en row ouput (feedback)
Row: datastructuur waarin alle input en ouput in omgezet wordt, stelt een rij van gekleurde pegs voor
Peg: datastructuur die een gekleurde peg voorsteld

Color: enum, stelt de mogelijke kleuren voor
Role: stelt de rol van breaker of maker voor






